import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../data-service.service';

@Component({
  selector: 'app-form3',
  templateUrl: './form3.component.html',
  styleUrls: ['./form3.component.css']
})
export class Form3Component implements OnInit {

  title = 'Angular Form 2';

  angForm: FormGroup;
  constructor(private fb: FormBuilder,
              public dataService: DataService) {
   this.createForm();

   this.angForm.valueChanges.subscribe(value => {
    this.dataService.form3 = this.angForm;
   });
 }
  createForm() {
   this.angForm = this.fb.group({
      name: ['', Validators.required ],
      address: ['', Validators.required ]
   });
 }
 ngOnInit() {
 }

}
