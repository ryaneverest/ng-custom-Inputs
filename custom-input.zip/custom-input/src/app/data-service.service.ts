import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class DataService {
form1: FormGroup = new FormGroup({});
form2: FormGroup = new FormGroup({});
form3: FormGroup = new FormGroup({});
  constructor() { }
}
