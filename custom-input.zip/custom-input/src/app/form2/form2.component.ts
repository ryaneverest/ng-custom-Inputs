import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../data-service.service';

@Component({
  selector: 'app-form2',
  templateUrl: './form2.component.html',
  styleUrls: ['./form2.component.css']
})



export class Form2Component implements OnInit {

  title = 'Angular Form 2';

   angForm: FormGroup;
   constructor(private fb: FormBuilder,
               public dataService: DataService) {
    this.createForm();
    this.angForm.valueChanges.subscribe(value => {
      this.dataService.form2 = this.angForm;
    });
  }
   createForm() {
    this.angForm = this.fb.group({
       name: ['', Validators.required ],
       address: ['', Validators.required ]
    });
  }
  ngOnInit() {
  }

}
