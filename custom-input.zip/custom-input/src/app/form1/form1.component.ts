import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../data-service.service';

@Component({
  selector: 'app-form1',
  templateUrl: './form1.component.html',
  styleUrls: ['./form1.component.css']
})
export class Form1Component implements OnInit {
   title = 'Angular Form Validation Tutorial';
   serviceCity: any = [
     {id: 1, itemName: 'Atlanta'},
     {id: 2, itemName: 'Suwanee'},
     {id: 3, itemName: 'Austin'}
  ];
 form1: FormGroup;
 constructor(private fb: FormBuilder,
             public dataService: DataService) {
  this.createForm();
  this.form1.valueChanges.subscribe(value => {
    this.dataService.form1 = this.form1;
  });
}
 createForm() {
  this.form1 = this.fb.group({
     name: ['', Validators.required ],
     address: ['', Validators.required ],
     serviceCity: ['', [Validators.required ]],
     serviceZip: ['', Validators.pattern('/(\d{5})/g') ]

  });
}

ngOnInit() {
}
}
