import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployerComponent } from './employer/employer.component';
import { EmployeeComponent } from './employee/employee.component';
import { Form1Component } from './form1/form1.component';
import { Form2Component } from './form2/form2.component';
import { Form3Component } from './form3/form3.component';


import {
  CustomInputComponent,
  CustomRadioComponent,
  CustomSelectComponent,
  CustomInputNumberComponent,
  CustomInputEmailComponent,
  CustomInputTelComponent,
  CustomTextareaComponent
} from './Custom-inputs/custom.component';

@NgModule({
  declarations: [
    AppComponent,
    EmployerComponent,
    EmployeeComponent,
    Form1Component,
    Form2Component,
    Form3Component,


    CustomInputComponent,
    CustomRadioComponent,
    CustomSelectComponent,
    CustomInputNumberComponent,
    CustomInputEmailComponent,
    CustomInputTelComponent,
    CustomTextareaComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
