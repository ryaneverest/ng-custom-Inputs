import { Component, Input, Output, EventEmitter, OnInit, forwardRef,
  ChangeDetectorRef, AfterViewInit, ChangeDetectionStrategy, ViewChild } from '@angular/core';
import { FormGroup, ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { debug } from 'util';
declare const $: any;

// gre-input
@Component({
   selector: 'starr-input',
   template: `
   <div [class]='cols'>
       <div class="form-group" *ngIf="form" [formGroup]="form">
           <label [for]="controlName">{{label}}</label>
           <input type="text" [maxlength]="maxlength" class="form-control" [required]='required'
            [formControlName]="controlName" [attr.name]="controlName"
             [title]='title ? title : placeholder' [attr.id]="controlName" [placeholder]="placeholder" (focus)="onFocus($event)">
           <span *ngIf="control.invalid && (control.dirty || control.touched)">
               <label [for]="controlName" *ngIf="control.errors.required" class="validation-error-label"> {{ errorMsg }} </label>
               <label [for]="controlName" *ngIf="control.errors.pattern" class="validation-error-label"> {{ errorMsgPattern }} </label>
               <label [for]="controlName" *ngIf="control.errors.maxlength" class="validation-error-label"> {{ errorMsgMaxLength }} </label>
               <label [for]="controlName" *ngIf="control.errors.minlength" class="validation-error-label"> {{ errorMsgMinLength }} </label>
           </span>
       </div>
   </div>`
})
export class CustomInputComponent implements OnInit {
   @Input() cols: string = null;
   @Input() form: FormGroup = null;
   @Input() control: any = null;
   @Input() label: string = null;
   @Input() placeholder: string = null;
   @Input() required: string = null;
   @Input() maxlength: number = null;
   @Input() errorMsg: string = null;
   @Input() errorMsgPattern: string = null;
   @Input() errorMsgMaxLength: string = null;
   @Input() errorMsgMinLength: string = null;
   @Output() focus = new EventEmitter();
   controlName: string = null;
   @Input() title: string = null;
   ngOnInit(): void {
       this.controlName = Object.keys(this.control.parent.controls).find(c => this.control === this.control.parent.controls[c]) || null;
       this.placeholder = this.placeholder ? this.placeholder : this.label;
   }
   onFocus($event): void { this.focus.emit($event); }
}

// // gre-input-masked
// @Component({
//    selector: 'starr-input-masked',
//    template: `
//    <div [class]='cols'>
//        <div class="form-group" *ngIf="form" [formGroup]="form">
//            <label [for]="controlName">{{label}}</label>
//            <input type="text" [maxlength]="maxlength" class="form-control" [required]='required'
//             [formControlName]="controlName" [attr.name]="controlName" [textMask]="textMask"
//              [attr.id]="controlName" [placeholder]="placeholder" (focus)="onFocus($event)">
//            <span *ngIf="control.invalid && (control.dirty || control.touched)">
//                <label [for]="controlName" *ngIf="control.errors.required" class="validation-error-label"> {{ errorMsg }} </label>
//                <label [for]="controlName" *ngIf="control.errors.pattern" class="validation-error-label"> {{ errorMsgPattern }} </label>
//                <label [for]="controlName" *ngIf="control.errors.maxlength" class="validation-error-label"> {{ errorMsgMaxLength }} </label>
//                <label [for]="controlName" *ngIf="control.errors.minlength" class="validation-error-label"> {{ errorMsgMinLength }} </label>
//            </span>
//        </div>
//    </div>`
// })
// export class CustomInputMaskComponent implements OnInit {
//    @Input() cols: string = null;
//    @Input() form: FormGroup = null;
//    @Input() control: any = null;
//    @Input() label: string = null;
//    @Input() placeholder: string = null;
//    @Input() required: string = null;
//    @Input() maxlength: number = null;
//    @Input() textMask: any = null;
//    @Input() errorMsg: string = null;
//    @Input() errorMsgPattern: string = null;
//    @Input() errorMsgMaxLength: string = null;
//    @Input() errorMsgMinLength: string = null;
//    @Output() focus = new EventEmitter();
//    controlName: string = null;
//    ngOnInit(): void {
//        this.controlName = Object.keys(this.control.parent.controls).find(c => this.control === this.control.parent.controls[c]) || null;
//        this.placeholder = this.placeholder ? this.placeholder : this.label;
//    }
//    onFocus($event): void { this.focus.emit($event); }
// }


// gre-radio
@Component({
   // changeDetection: ChangeDetectionStrategy.OnPush,
   selector: 'starr-radio',
   template: `
   <div [class]='cols'>
       <div class="form-group" *ngIf="form" [formGroup]="form">
           <label class="control-label {{validateLabel ? 'blue-label' : ''}}" [for]="controlName">{{label}}</label>
           <div class="control-group">
               <label *ngFor='let value of inputValues' class="control control-radio ml-10" > {{value}}
                   <input type="radio"  [value]='value' (change)="onChange()" [name]="controlName" [formControlName]="controlName" />
                   <div class="control_indicator"></div>
               </label>
           </div>
           <span *ngIf="control.invalid && (control.dirty || control.touched)">
               <label [for]="controlName" *ngIf="control.errors.required" class="validation-error-label" style="margin-left: 12px;">
                   Please select one.
               </label>
           </span>
       </div>
   </div>`,
   styles: [`
       .control-group { width: fit-content; }
       .control { display: inline !important; }
       @media(max-width: 768px) and (min-width: 300px) { .control { display: block !important; }
   `]
})
export class CustomRadioComponent implements OnInit {
   @Input() cols: string = null;
   @Input() form: FormGroup = null;
   @Input() control: any = null;
   @Input() label: string = null;
   @Input() validateLabel: boolean = null;
   @Input() inputValues: string[] = null;
   // required: string = '';
   controlName: string = null;
   @Output() focus: EventEmitter<any> = new EventEmitter(true);
   constructor() {}
   ngOnInit() {
       this.controlName = Object.keys(this.control.parent.controls).find(c => this.control === this.control.parent.controls[c]) || null;
   }
   onChange() { this.focus.emit({ controlName: this.controlName, value: this.form.controls
     [this.controlName].value ? this.form.controls[this.controlName].value : '' }); }
}

// gre-Select
@Component({
   selector: 'starr-select',
   template: `
   <div [class]='cols'>
       <div class="form-group" *ngIf="form" [formGroup]="form">
           <label class="control-label" [for]="controlName">{{label}}</label>

           <select [formControlName]="controlName" (change)="onChange($event)">
   <option value="" disabled>Choose your city</option>
   <option *ngFor="let item of items" [ngValue]="item.id">{{item.itemName}}</option>
</select>

           <span *ngIf="control.invalid && (control.dirty || control.touched)">
               <label [for]="controlName" *ngIf="control.errors.required" class="validation-error-label"> {{ errorMsg }}</label>
           </span>
       </div>
   </div>
   `,
})
export class CustomSelectComponent implements OnInit {
   @Input() form: FormGroup = null;
   @Input() control: any = null;
   @Input() label: string = null;
   @Input() placeholder: string = null;
   @Input() required: string = null;
   @Input() cols: string = null;
   @Input() errorMsg: string = null;
   @Input() items: any[] = null;
   @Output() onSelect = new EventEmitter();
   @Output() onDeselect = new EventEmitter();
   @Output() onClick = new EventEmitter();
   controlName: string = null;
   ngOnInit(): void {
       this.controlName = Object.keys(this.control.parent.controls).find(c => this.control === this.control.parent.controls[c]) || null;
   }
   onChange($event): void { this.onSelect.emit($event); }
   onRemove($event): void { this.onDeselect.emit($event); }
   clicked($event): void { this.onClick.emit($event); }
}

// gre-number
@Component({
   selector: 'starr-number',
   template: `
   <div [class]='cols'>
       <div class="form-group" *ngIf="form" [formGroup]="form">
           <label [for]="controlName">{{label}}</label>
           <input type="number" class="form-control" [required]='required'
            [formControlName]="controlName" [attr.name]="controlName" [attr.id]="controlName"
             [placeholder]="placeholder" (focus)="onFocus($event)">
           <span *ngIf="control.invalid && (control.dirty || control.touched)">
               <label [for]="controlName" *ngIf="control.errors.required" class="validation-error-label"> {{ errorMsg }} </label>
               <label [for]="controlName" *ngIf="control.errors.pattern" class="validation-error-label"> {{ errorMsgPattern }} </label>
           </span>
       </div>
   </div>
   `
})
export class CustomInputNumberComponent implements OnInit {
   @Input() cols: string = null;
   @Input() form: FormGroup = null;
   @Input() control: any = null;
   @Input() label: string = null;
   @Input() placeholder: string = null;
   @Input() required: string = null;
   @Input() errorMsg: string = null;
   @Input() errorMsgPattern: string = null;
   @Output() focus = new EventEmitter();
   controlName: string = null;
   ngOnInit(): void {
       this.controlName = Object.keys(this.control.parent.controls).find(c => this.control === this.control.parent.controls[c]) || null;
       this.placeholder = this.placeholder ? this.placeholder : this.label;
   }
   onFocus($event): void { this.focus.emit($event); }
}

// gre-email
@Component({
   selector: 'starr-email',
   template: `
   <div [class]='cols'>
       <div class="form-group" *ngIf="form" [formGroup]="form">
           <label [for]="controlName">{{label}}</label>
           <input type="email" [maxlength]="maxlength" class="form-control" [required]='required'
            [formControlName]="controlName" [attr.name]="controlName" [attr.id]="controlName"
             [placeholder]="placeholder" (focus)="onFocus($event)">
           <span *ngIf="control.invalid && (control.dirty || control.touched)">
               <label [for]="controlName" *ngIf="control.errors.required" class="validation-error-label"> {{ errorMsg }} </label>
               <label [for]="controlName" *ngIf="control.errors.pattern" class="validation-error-label"> {{ errorMsgPattern }} </label>
           </span>
       </div>
   </div>`
})
export class CustomInputEmailComponent implements OnInit {
   @Input() cols: string = null;
   @Input() form: FormGroup = null;
   @Input() control: any = null;
   @Input() label: string = null;
   @Input() placeholder: string = null;
   @Input() required: string = null;
   @Input() maxlength: number = null;
   @Input() errorMsg: string = null;
   @Input() errorMsgPattern: string = null;
   @Output() focus = new EventEmitter();
   controlName: string = null;
   ngOnInit(): void {
       this.controlName = Object.keys(this.control.parent.controls).find(c => this.control === this.control.parent.controls[c]) || null;
       this.placeholder = this.placeholder ? this.placeholder : this.label;
   }
   onFocus($event): void { this.focus.emit($event); }
}

// gre-tel
@Component({
   selector: 'starr-tel',
   template: `
   <div [class]='cols'>
       <div class="form-group" *ngIf="form" [formGroup]="form">
           <label [for]="controlName">{{label}}</label>
           <input type="tel" [maxlength]="maxlength" class="form-control" [required]='required'
            [formControlName]="controlName" [attr.name]="controlName" [attr.id]="controlName"
             [placeholder]="placeholder" (focus)="onFocus($event)">
           <span *ngIf="control.invalid && (control.dirty || control.touched)">
               <label [for]="controlName" *ngIf="control.errors.required" class="alert alert-danger"> {{ errorMsg }} </label>
               <label [for]="controlName" *ngIf="control.errors.pattern" class="alert alert-danger"> {{ errorMsgPattern }} </label>
           </span>
       </div>
   </div>`
})
export class CustomInputTelComponent implements OnInit {
   @Input() cols: string = null;
   @Input() form: FormGroup = null;
   @Input() control: any = null;
   @Input() label: string = null;
   @Input() placeholder: string = null;
   @Input() required: string = null;
   @Input() maxlength: number = null;
   @Input() errorMsg: string = null;
   @Input() errorMsgPattern: string = null;
   @Output() focus = new EventEmitter();
   controlName: string = null;
   ngOnInit(): void {
       this.controlName = Object.keys(this.control.parent.controls).find(c => this.control === this.control.parent.controls[c]) || null;
       this.placeholder = this.placeholder ? this.placeholder : this.label;
   }
   onFocus($event): void { this.focus.emit($event); }
}

// gre-toggle
@Component({
   selector: 'starr-toggle',
   template: `
   <div class='switchery-container'>
       <label class="switch">
           <input type="checkbox" [value]="value" [checked]="value" (click)="switch()" [attr.id]="id" [attr.name]="id">
           <span class="slider round" data-on="On" data-off="Off"></span>
       </label>
       <span class='switch-label' (click)="switch()" style='cursor: pointer;'>{{label}}</span >
   </div>
   `,
   styles: [`.switchery-container {display: block;display: -moz-inline-stack;*display: inline; white-space: normal;`],
   providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SwitchComponent), multi: true }]
})
export class SwitchComponent implements ControlValueAccessor {
   @Input() label = '';
   @Input() id = '';
   @Input() form: FormGroup = null;
   @Input('value') _value = null;
   onChange: any = () => { };
   onTouched: any = () => { };
   get value() { return this._value; }
   set value(val) {
     this._value = val;
     this.onChange(val);
     this.onTouched();
   }
   constructor() { }
   registerOnChange(fn) { this.onChange = fn; }
   writeValue(value) { this.value = value; }
   registerOnTouched(fn) { this.onTouched = fn; }
   switch() { this.value = !this.value; }
}

// gre-date
@Component({
   selector: 'starr-date',
   template: `
   <div [class]="cols">
       <div class="form-group pt-form-group-material" [formGroup]="form">
           <label class="control-label text-semibold">{{label}}</label>
           <input class="form-control" (blur)="blurDate()"[required]='required'
           [options]='dateOptions' [placeholder]="placeholder"
            [formControlName]="controlName" type="text"
             daterangepicker (selected)="updateDateRange($event, 'controlName')" [attr.name]="controlName" [attr.id]="controlName">
       </div>
       <span *ngIf="control.invalid && (control.dirty || control.touched)">
           <label [for]="controlName" *ngIf="control.errors.required" class="validation-error-label"> {{errorMsg}} </label>
       </span>
   </div>`
})
export class CustomDateComponent implements OnInit {
   @Input() form: FormGroup = null;
   @Input() control: any = null;
   @Input() label: string = null;
   @Input() cols: string = null;
   @Input() placeholder: string = null;
   @Input() required = '';
   @Input() errorMsg: string = null;
   // @Input() errorMsgPattern: string = null;
   // @Input() errorMsgMaxLength: string = null;
   // @Input() errorMsgMinLength: string = null;

   @Output() blur = new EventEmitter();
   controlName: string = null;
   ngOnInit(): void {
       this.controlName = Object.keys(this.control.parent.controls).find(c => this.control === this.control.parent.controls[c]) || null;
       if (this.form.controls[this.controlName].value === null || this.form.controls[this.controlName].value === '') {
           const selectedDate: any = new Date();
           this.form.controls[this.controlName].setValue(selectedDate, { onlySelf: true });
           this.form.updateValueAndValidity();
       }
   }
   blurDate() {
       if (this.form.controls[this.controlName].value === null || this.form.controls[this.controlName].value === '') {
       const selectedDate: any = new Date();
       this.form.controls[this.controlName].setValue(selectedDate, { onlySelf: true });
       this.form.updateValueAndValidity();
       }
   }

   updateDateRange($event: any, controlName): void {
       const selectedDate: any = new Date();
       this.form.controls[this.controlName].setValue(selectedDate, { onlySelf: true });
       this.form.updateValueAndValidity();
   }
}

// gre-dateinput
@ViewChild('date')
@Component({
   selector: 'starr-date',
   template: `
   <div [class]="cols">
       <div class="form-group pt-form-group-material" [formGroup]="form">
           <label class="control-label text-semibold">{{label}}</label>
           <input class="form-control" [options]='dateOptions'
            [formControlName]="controlName" type="text" [placeholder]="placeholder"
             daterangepicker
             (selected)="updateDateRange($event, 'controlName')" [attr.name]="controlName" [attr.id]="controlName">
           <span *ngIf="control.invalid && (control.dirty || control.touched)">
             <label [for]="controlName" *ngIf="control.errors.required" class="validation-error-label"> {{errorMsg}} </label>
             <label [for]="controlName" *ngIf="control.errors.pattern" class="validation-error-label"> {{ errorMsgPattern }} </label>
           </span>
       </div>
   </div>`
})
export class CustomDateInputComponent implements OnInit {
   @Input() form: FormGroup = null;
   @Input() control: any = null;
   @Input() label: string = null;
   @Input() cols: string = null;
   @Input() placeholder: string = null;
   @Input() required = '';
   @Input() errorMsg: string = null;
   @Input() errorMsgPattern: string = null;
   @Input() clicked = false;
   // @Input() errorMsgPattern: string = null;
   // @Input() errorMsgMaxLength: string = null;
   // @Input() errorMsgMinLength: string = null;
   public dateOptions: any = {
       locale: { format: 'MM/DD/YYYY' },
       alwaysShowCalendars: false,
       singleDatePicker: true,
       autoUpdateInput: false,
       showDropdowns: true,
       date: {
         startDate: null,
         endDate: null
       }
   };
   @Output() blur = new EventEmitter();
   @Output() click = new EventEmitter();
   controlName: string = null;
   ngOnInit(): void {
       this.controlName = Object.keys(this.control.parent.controls).find(c => this.control === this.control.parent.controls[c]) || null;
       this.placeholder = this.placeholder ? this.placeholder : this.label;
   }
   updateDateRange($event: any, controlName): void {
       const selectedDate = '';
       this.form.controls[this.controlName].setValue(selectedDate, { onlySelf: true });
       this.form.updateValueAndValidity();
   }


}

// gre-textbox
@Component({
   selector: 'starr-textarea',
   template: `
   <div>
       <div class="form-group" *ngIf="form" [formGroup]="form">
           <label [for]="controlName">{{label}}</label>
           <textarea  [rows]="rows" [cols]="cols"  [maxlength]="maxlength" class="form-control" [required]='required'
            [formControlName]="controlName" [attr.name]="controlName" [attr.id]="controlName"
             [placeholder]="placeholder" (focus)="onFocus($event)">
           </textarea>
           <span *ngIf="control.invalid && (control.dirty || control.touched)">
               <label [for]="controlName" *ngIf="control.errors.required" class="validation-error-label"> {{ errorMsg }} </label>
               <label [for]="controlName" *ngIf="control.errors.pattern" class="validation-error-label"> {{ errorMsgPattern }} </label>
               <label [for]="controlName" *ngIf="control.errors.maxlength" class="validation-error-label"> {{ errorMsgMaxLength }} </label>
               <label [for]="controlName" *ngIf="control.errors.minlength" class="validation-error-label"> {{ errorMsgMinLength }} </label>
           </span>
       </div>
   </div>`
})
export class CustomTextareaComponent implements OnInit {
   @Input() rows: number = null;
   @Input() cols: number = null;
   @Input() form: FormGroup = null;
   @Input() control: any = null;
   @Input() label: string = null;
   @Input() placeholder: string = null;
   @Input() required: string = null;
   @Input() maxlength: number = null;
   @Input() errorMsg: string = null;
   @Input() errorMsgPattern: string = null;
   @Input() errorMsgMaxLength: string = null;
   @Input() errorMsgMinLength: string = null;
   @Output() focus = new EventEmitter();
   controlName: string = null;
   ngOnInit(): void {
       this.controlName = Object.keys(this.control.parent.controls).find(c => this.control === this.control.parent.controls[c]) || null;
       this.placeholder = this.placeholder ? this.placeholder : this.label;
   }
   onFocus($event): void { this.focus.emit($event); }
}
